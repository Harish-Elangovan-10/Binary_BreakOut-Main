Solve This:

30 ÷ (5 + 1) × 8 ÷ 2