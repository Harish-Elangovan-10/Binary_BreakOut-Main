Statements

Some keys are locks.
All locks are metal.
No metal is plastic.

Question: Which conclusion CANNOT be true? Choose the correct folder.