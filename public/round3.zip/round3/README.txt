KEEP THESE POINTS IN MIND:

1. Read the folder name carefully — the answer to the questions will lead you to the next folder.

2. This system contains decoy directories, so clicking blindly may trigger traps.

3. It is mandatory to read any text file first, as it may contain questions or instructions.

4. Finish as quickly as possible — time matters.